#include <stdio.h>
#include "export.h"

#define ARRLEN(arr) (sizeof(arr)/sizeof(arr[0]))

#define idldata(var) (var)->value.arr->data

#define coor(x,y,z) ((x)+xs*((y)+(z)*ys))

#define d(var,i) idldata(var)[i]

typedef UCHAR IDL_BYTE;

int find_indices(IDL_LONG *dimsp, double *np, double *pp, double th, 
		 IDL_LONG *points_list)
{
  int i=0;
  IDL_LONG x, y, z;

  for (z = 0; z < dimsp[2]; z++)
    for (y = 0; y < dimsp[1]; y++)
      for (x = 0; x < dimsp[0]; x++)
	if ( abs(np[0] * (x - pp[0]) +
		 np[1] * (y - pp[1]) +
		 np[2] * (z - pp[2])) < th )
	  {
	    if (points_list != NULL) points_list[i] = (x + dimsp[0] * (y + z * dimsp[1]));
	    i++;
	  }
  return i;
}

static void clip_plane(int argc, IDL_VPTR *argv)
{
  IDL_VPTR src, n, p;
  IDL_LONG xs, ys, zs;
  IDL_LONG x, y, z;
  IDL_LONG *np, *pp;
  IDL_BYTE *srcp;
  int ncvt=0,pcvt=0;

  src = argv[0];
  n = argv[1];
  p = argv[2];
  /* argument checking */
  IDL_ENSURE_SIMPLE(src);
  IDL_ENSURE_SIMPLE(n);
  IDL_ENSURE_SIMPLE(p);
  IDL_ENSURE_ARRAY(src);
  IDL_ENSURE_ARRAY(n);
  IDL_ENSURE_ARRAY(p);
  
  /*
    printf("n: %d,%d,%d\n",d(n,0),d(n,1),d(n,2));
    printf("p: %d,%d,%d\n",d(p,0),d(p,1),d(p,2));
    printf("n dims: %d\n",n->value.arr->n_dim);
    printf("n dims: %d\n",n->value.arr->dim[0]);
  */

  if (src->value.arr->n_dim != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"first arg has to be 3D");
  if (n->value.arr->n_elts != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"second arg has to be a 3-vector");
  if (p->value.arr->n_elts != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"third arg has to be a 3-vector");
  
  if (src->type != IDL_TYP_BYTE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, "must be Byte...");
    }
  if (n->type != IDL_TYP_LONG)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Long...");
      n = IDL_CvtLng(1, argv+1);
      ncvt = 1;
    }
  if (p->type != IDL_TYP_LONG)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Long...");
      p = IDL_CvtLng(1, argv+2);
      pcvt = 1;
    }

  srcp = (IDL_BYTE *) idldata(src);
  np = (IDL_LONG *) idldata(n);
  pp = (IDL_LONG *) idldata(p);

  printf("n: %d,%d,%d\n",np[0],np[1],np[2]);
  printf("p: %d,%d,%d\n",pp[0],pp[1],pp[2]);

  xs = src->value.arr->dim[0];
  ys = src->value.arr->dim[1];
  zs = src->value.arr->dim[2];

  for (z = 0; z < zs; z++)
    for (y = 0; y < ys; y++)      
      for (x = 0; x < xs; x++) 
	if ((np[0] * (x - pp[0]) +
	     np[1] * (y - pp[1]) +
	     np[2] * (z - pp[2])) < 0)
	  srcp[coor(x,y,z)] = 0;
  
  if (ncvt)
    IDL_Deltmp(n);
  if (pcvt)
    IDL_Deltmp(p);

}

static IDL_VPTR thick_plane_points(int argc, IDL_VPTR *argv)
{
  
  /* thick_plane_points(dims, n, p, th)
     returns long indices of points in volume with sides
     dims = [x,y,z], and in plane th thick given by the 
     normal vector n and the point p */

  IDL_VPTR dims, n, p, th, temp;
  double *np, *pp, thval;
  IDL_LONG *dimsp, *points_list;
  int dims_cvt=0,ncvt=0, pcvt=0;
  int i;
  
  dims = argv[0];
  n = argv[1];
  p = argv[2];
  th = argv[3];
  
  for (i = 0;i<4;i++) { IDL_ENSURE_SIMPLE(argv[i]); }
  IDL_ENSURE_ARRAY(dims);
  IDL_ENSURE_ARRAY(n);
  IDL_ENSURE_ARRAY(p);
  IDL_ENSURE_SCALAR(th);

  if (dims->value.arr->n_elts != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"first arg has to be a 3-vector");
  if (n->value.arr->n_elts != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"second arg has to be a 3-vector");
  if (p->value.arr->n_elts != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"third arg has to be a 3-vector");
  
  if (dims->type != IDL_TYP_LONG)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting dims to Long...");
      dims = IDL_CvtLng(1, argv);
      dims_cvt = 1;
    }
  if (n->type != IDL_TYP_DOUBLE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting n to Double...");
      n = IDL_CvtDbl(1, argv+1);
      ncvt = 1;
    }
  if (p->type != IDL_TYP_DOUBLE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting p to Double...");
      p = IDL_CvtDbl(1, argv+2);
      pcvt = 1;
    }
  thval = th->value.d;

  dimsp = (IDL_LONG *) idldata(dims);
  np    = (double *) idldata(n);
  pp    = (double *) idldata(p);

  printf("dims: %d,%d,%d\n",dimsp[0],dimsp[1],dimsp[2]);
  printf("n: %.1f,%.1f,%.1f\n",np[0],np[1],np[2]);
  printf("p: %.1f,%.1f,%.1f\n",pp[0],pp[1],pp[2]);

  i = find_indices(dimsp, np, pp, thval, NULL);
  points_list = (IDL_LONG *) 
    IDL_MakeTempVector(IDL_TYP_LONG, (IDL_MEMINT) i+1 , IDL_ARR_INI_ZERO, &temp);
  find_indices(dimsp, np, pp, thval, points_list);

#define chktmp(flag,vptr) if (flag) IDL_Deltmp(vptr)
  chktmp(dims_cvt,dims);
  chktmp(ncvt,n);
  chktmp(pcvt,p);

  return temp; 
}


int IDL_Load(void)
{
  static IDL_SYSFUN_DEF procedure_addr[] = {
    { (IDL_FUN_RET) clip_plane, "CLIP_PLANE", 3, 3, 0 }
  };

  static IDL_SYSFUN_DEF function_addr[] = {
    { thick_plane_points, "THICK_PLANE_POINTS", 4, 4, 0}
  };

  return IDL_AddSystemRoutine(procedure_addr, FALSE, ARRLEN(procedure_addr))
    && IDL_AddSystemRoutine(function_addr, TRUE, ARRLEN(function_addr));
}
