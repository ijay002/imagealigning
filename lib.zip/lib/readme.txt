------------------------------------------------------------
README file: <RSI_Directory>
	       <IDL_Directory>
		  lib
------------------------------------------------------------

This directory contains code for IDL routines written in the
IDL language. We recommend that you do not store your own
library files in this directory, as it may be overwritten
by the IDL installation program if you choose to remove or
install components of the IDL distribution. Instead, store
your own routines in a separate directory and include that
directory in the IDL path.
