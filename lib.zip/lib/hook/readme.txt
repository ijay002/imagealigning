------------------------------------------------------------
README file: <RSI_Directory>
	       <IDL_Directory>
		  lib
		    hook
------------------------------------------------------------

This directory contains files which are linked to
the IDL distribution. Unless you are building a Runtime IDL
application, Research Systems recommends that you do not
store your own files in this directory.

