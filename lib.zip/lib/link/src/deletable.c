#include <stdio.h>
#include <stdlib.h>

/* different types of connectivity */
typedef enum etconn { c26, c6, c18 } Tconn;
typedef unsigned char byte;

#define CPIX 13    /* index of center pixel in a 3x3x3 cube */
 
/* prototypes */
int deletable(byte *sarr);
int t26unity(byte *sarr, int *nb, int ni[27][26], int ftot);
int t6unity(byte *sarr, int *nb, int ni[27][26]);
int idx(int x, int y, int z);
int checkidx(int idx, Tconn con);
void getinds(int ni[27][26], int *nb, Tconn con);

/* idx, checkidx and getinds (and the debug function printnbs) are just 
 *  helper functions to precompute the indices of connected neighbours for
 *  any voxel in the 3x3x3 cube
 */

#ifdef IDEBUG
void printnbs(int ni[27][26], int *nb)
{
  int i, j, ind, x, y, z, xy;

  for (i=0; i<27; i++)
    {
      xy = i % 9;
      y = xy / 3;
      x = xy % 3;
      z = i / 9;
      printf(" point (%d,%d,%d) [%d] has %d neighbours:\n",x,y,z,i,nb[i]);
      for (j=0; j<nb[i]; j++)
	{
	  ind = ni[i][j];
	  xy = ind % 9;
	  y = xy / 3;
	  x = xy % 3;
	  z = ind / 9;
	  printf("\t(%d,%d,%d) [%d]\n",x,y,z,ind);
	}
    }
}
#endif

#define range(x) ((x) >= 0 && (x) < 3)
int idx(int x, int y, int z)
{
   if (range(x) && range(y) && range(z))
      return x + 3*y + 9*z;
   else
      return -1;
}

int checkidx(int idx, Tconn con)
{
/* reject corner indices for c6 case */
   int i;
   int corners[] = {0, 2, 6, 8, 18, 20, 24, 26};
   int cn = sizeof(corners)/sizeof(int);
   
   if (con == c26)
      return 1;
   if (con == c6)
      for (i=0; i<cn; i++)
         if (idx == corners[i])
           return 0;
   return 1;
} 

void getinds(int ni[27][26], int *nb, Tconn con)
{
  /* precompute the neighbour arrays */
  int i,j;
  int nind[27];
  int xy, x, y, z, nn, n;

  for (i=0; i<27; i++)
    {
      xy = i % 9;
      y = xy / 3;
      x = xy % 3;
      z = i / 9;

      switch (con) {
       case c26:
         nind[0] = idx(x,y+1,z);
         nind[1] = idx(x,y-1,z);
         nind[2] = idx(x+1,y,z);
         nind[3] = idx(x-1,y,z);
         nind[4] = idx(x+1,y+1,z);
         nind[5] = idx(x-1,y-1,z);
         nind[6] = idx(x-1,y+1,z);
         nind[7] = idx(x+1,y-1,z);

         nind[8] = idx(x,y+1,z+1);
         nind[9] = idx(x,y-1,z+1);
         nind[10] = idx(x+1,y,z+1);
         nind[11] = idx(x-1,y,z+1);
         nind[12] = idx(x+1,y+1,z+1);
         nind[13] = idx(x-1,y-1,z+1);
         nind[14] = idx(x-1,y+1,z+1);
         nind[15] = idx(x+1,y-1,z+1);

         nind[16] = idx(x,y+1,z-1);
         nind[17] = idx(x,y-1,z-1);
         nind[18] = idx(x+1,y,z-1);
         nind[19] = idx(x-1,y,z-1);
         nind[20] = idx(x+1,y+1,z-1);
         nind[21] = idx(x-1,y-1,z-1);
         nind[22] = idx(x-1,y+1,z-1);
         nind[23] = idx(x+1,y-1,z-1);

         nind[24] = idx(x,y,z+1);
         nind[25] = idx(x,y,z-1);
         nn = 26;
         break;
       case c6:
         nind[0] = idx(x,y+1,z);
         nind[1] = idx(x,y-1,z);
         nind[2] = idx(x+1,y,z);
         nind[3] = idx(x-1,y,z);
         nind[4] = idx(x,y,z+1);
         nind[5] = idx(x,y,z-1);
         nn = 6;
         break;
       case c18:
         /* fill in here */
         nn = 18;
         break;
       default:
         fprintf(stderr,"Unknown type of connectivity\n");
         exit(-1);
         break;
      }

      n = 0;
      for (j=0; j<nn; j++)
	if (nind[j] >= 0 && nind[j] != CPIX && checkidx(nind[j],con))
	  ni[i][n++] = nind[j];
      nb[i] = n;
    }
}


int deletable(byte *sarr)
{
/* test if a point at the center of a 3x3x3 cube is deletable
   return 1 (true) if:
     more than one foreground neighbour  &&
     T26 == 1  &&
     T6 == 1

 * where foreground: voxel > 0
 *       background: voxel == 0
   T26 and T6 are tested if equal to one (no explicit computation if > 1)
   by calling the functions t[6,26]unity to which precomputed
   arrays of neighbour-indices for 26- and 6-connectivity are passed
   to speed up computation.

   For characterisation of simple points by means of T26 and T6 see
   Bertrand & Malandain (1994). A new characterization of simple points.
   Pattern Recognition Letters 15: 169-175.

   input : byte array sarr is assumed to be a 3x3x3 array with the
           pixel in question at its center
*/ 
   static int ni[27][26], bni[27][26];
   static int nb[27], bnb[27];
   static int first=1;
   int i;
   int nfg=0;

   if (first)
    {
       first = 0;
#ifdef FDEBUG
      printf("getting index luts...\n");
#endif
      getinds(ni, nb, c26);
      getinds(bni, bnb, c6);
    }

   /* count number of noncenter foreground pixels */
   for (i=0; i<27; i++)
       if (sarr[i]>0 && i != CPIX)
	 nfg++;

   /* do not delete endpoints (have only one neighbour) */
   if (nfg <= 1)
      return 0;

   /* check T26 and T6 */
   return(t26unity(sarr, nb, ni, nfg) && 
           t6unity(sarr, bnb, bni));
}

int t26unity(byte *sarr, int *nb, int ni[27][26], int ftot)
{
  /* test if a voxel at the center of a 3x3x3 cube is simple.
   * This function tests the first part of the criteria, i.e. if
   * T26 == 1. T26: number of 26-connected foreground regions in
   * N26-{center} which are 26 connected to center. For details see
   * Bertrand & Malandain (1994). A new characterization of simple points.
   * Pattern Recognition Letters 15: 169-175.

   * inputs: sarr: 3x3x3 subarray as a 1D c-array 
   *         nb, ni: arrays containing number and indices of neighbours
   *                 for each of the 27 voxels in cube
   *         ftot: total number of off-center foreground pixels in cube
   *
   * output: 1 if simply connected, 0 otherwise
   */

  int i=0, new=0, end, id;
  int ctot, j, ind;
  int found[27]={0,0,0,0,0,0,0,0,0,
		 0,0,0,0,0,0,0,0,0,
		 0,0,0,0,0,0,0,0,0};
  int inds[26];

  /* find a starting point which is connected to the center voxel
   * (using whichever connectivity is appropriate */
  i = -1;
  for (j=0; j<nb[CPIX]; j++)
    if (sarr[ni[CPIX][j]] > 0)
      {
	i = ni[CPIX][j];
	break;
      }

  if (i < 0) return 0;

  ctot = 1;   /* count number of pixels as they are found */
  found[i]=1;
  for (j=0, ind=ni[i][0]; j<nb[i]; j++, ind=ni[i][j])
    {
      if (sarr[ind]>0 && !found[ind])
	{
	  inds[new++]=ind;
	  found[ind]=1;
	}
    }

  while (new) /* loop as long as we find new pixels */
    {
      ctot += new;
      end = new;
      new = 0;
      for (i=0; i<end; i++)
       {
        id = inds[i];
	for (j=0, ind=ni[id][0]; j<nb[id]; j++, ind=ni[id][j])
	    if (sarr[ind]>0 && !found[ind])
	    {
	      inds[new++]=ind;
	      found[ind]=1;
	    }
       }
    }

   return ctot == ftot; /* check if all pixels have been found to be in this
			    connected region */
}


int t6unity(byte *sarr, int *nb, int ni[27][26])
{
  /* test if a voxel at the center of a 3x3x3 cube is simple.
   * This function tests the second part of the criteria, i.e. if
   * T6 == 1. T6: number of 6-connected background regions in N18-{center}
   * which are 6 connected to center. For details see
   * Bertrand & Malandain (1994). A new characterization of simple points.
   * Pattern Recognition Letters 15: 169-175.

   * inputs: sarr: 3x3x3 subarray as a 1D c-array 
   *         nb, ni: arrays containing number and indices of neighbours
   *                 for each of the 27 voxels in cube
   *
   * output: 1 if simply connected, 0 otherwise
   */

  int i=0, new=0, end, id;
  int ctot, j, ind;
  int found[27]={0,0,0,0,0,0,0,0,0,
		 0,0,0,0,0,0,0,0,0,
		 0,0,0,0,0,0,0,0,0};
  int inds[26];

  /* find a starting point which is connected to the center voxel
   * (using whichever connectivity is appropriate */
  i = -1;
  for (j=0; j<nb[CPIX]; j++)
    if (sarr[ni[CPIX][j]] == 0)
      {
	i = ni[CPIX][j];
	break;
      }

  if (i < 0) return 0;

  /* printf("starting search at index %d\n",i); */
   
  ctot = 1;   /* count number of pixels as they are found */
  found[i]=1;
  for (j=0, ind=ni[i][0]; j<nb[i]; j++, ind=ni[i][j])
    {
      if (sarr[ind]==0 && !found[ind])
	{
	   /* printf("found new neighbour at %d\n",ind); */
	   inds[new++]=ind;
	  found[ind]=1;
	}
    }

  while (new) /* loop as long as we find new pixels */
    {
      ctot += new;
      end = new;
      new = 0;
      for (i=0; i<end; i++)
       {
        id = inds[i];
	  /* printf("testing at %d\n",id); */
	  for (j=0, ind=ni[id][0]; j<nb[id]; j++, ind=ni[id][j])
	    {
	       /* printf("     ctesting %d...",ind); */
	       if (sarr[ind]==0 && !found[ind])
		 {
		    /* printf("found new neighbour at %d\n",ind); */
		    inds[new++]=ind;
		    found[ind]=1;
		 }
	       /* printf("\n"); */
	    }
       }
    }

#ifdef IDEBUG
   printf("found %d connected background pixels\n",ctot);
#endif
   for (i=0, ind=ni[CPIX][0]; i<6; i++, ind=ni[CPIX][i])
     if (sarr[ind]==0 && !found[ind]) /* test if another one is connected */
       return 0;

#ifdef IDEBUG
   printf("T6 is one\n",ctot);
#endif
   return 1;          /* no other pixel is connected */
}
