#include <stdio.h>
#include "export.h"

void cubecopy(UCHAR *src, UCHAR *dst, IDL_LONG* dim, IDL_LONG idx);
int deletable(UCHAR *sarr);  /* defined in another module */

IDL_VPTR IDLdeletable(int argc, IDL_VPTR argv[])
{
  IDL_VPTR src, result, idx;
  UCHAR cube[27];
  int cvt=0;
  IDL_LONG dim[IDL_MAX_ARRAY_DIM];
  IDL_LONG index;

  dim[0] = 3;
  dim[1] = 3;
  dim[2] = 3;

  /* argument checking */
  src = argv[0];
  IDL_ENSURE_SIMPLE(src);
  IDL_ENSURE_ARRAY(src);

  index = IDL_LongScalar(argv[1]);

  if (src->value.arr->n_dim != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"input array has to be 3D");

  /* type checking */
  if (src->type != IDL_TYP_BYTE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Byte...");
      src = IDL_CvtByte(1, argv);
      cvt = TRUE;
    }

  /* create variable to hold result */
  result = IDL_Gettmp();
  result->type = IDL_TYP_BYTE;
  result->value.c = 0;

  /* copy the cube into our temporary array */
  cubecopy((UCHAR *) src->value.arr->data, (UCHAR *) cube, 
	   src->value.arr->dim, index);

  if (deletable(cube))
    result->value.c = 1;

  /* cleanup */
  if (cvt) IDL_Deltmp(src);
  return(result);
}

IDL_VPTR extrcube(int argc, IDL_VPTR argv[])
{
  IDL_VPTR src, result, idx;
  void *outdata;
  int cvt=0;
  IDL_LONG dim[IDL_MAX_ARRAY_DIM];
  IDL_LONG index;

  dim[0] = 3;
  dim[1] = 3;
  dim[2] = 3;

  /* argument checking */
  src = argv[0];
  IDL_ENSURE_SIMPLE(src);
  IDL_ENSURE_ARRAY(src);

  index = IDL_LongScalar(argv[1]);

  if (src->value.arr->n_dim != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"input array has to be 3D");

  /* type checking */
  if (src->type != IDL_TYP_BYTE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Byte...");
      src = IDL_CvtByte(1, argv);
      cvt = TRUE;
    }

  /* create variable to hold result */
  outdata = (void *) IDL_MakeTempArray(IDL_TYP_BYTE, 3, dim, 
                             IDL_BARR_INI_NOP,&result);

  /* and actually copy it */
  cubecopy((UCHAR *) src->value.arr->data, (UCHAR *) outdata, 
	   src->value.arr->dim, index);

  /* cleanup */
  if (cvt) IDL_Deltmp(src);
  return(result);
}

#define dec(x) ( (x) > 0)
#define inc(x,lim) ( (x) < (lim) ) 
#define coor(x,y,z) ((x)+xs*((y)+(z)*ys))
/* copy a 3x3x3 cube centred at linear index 'idx' from src to dst */
void cubecopy(UCHAR *src, UCHAR *dst, IDL_LONG* dim, IDL_LONG idx)
{
  IDL_LONG xy, x, y, z;
  register IDL_LONG xs, ys, zs;
  register IDL_LONG xsm1, ysm1, zsm1;
  int i;

  xs = dim[0]; ys = dim[1]; zs = dim[2];
  xy = idx % (xs*ys);
  y = xy / xs;
  x = xy % xs;
  z = idx / (xs*ys);

  xsm1 = xs - 1;
  ysm1 = ys - 1;
  zsm1 = zs - 1;

  if (dec(z))
    {   /* lowest 3x3 plane */
      if (dec(x) && dec(y))
	dst[0] = src[coor(x-1,y-1,z-1)];
      else
	dst[0] = 0;
      if (dec(y))
	dst[1] = src[coor(x,y-1,z-1)];
      else
	dst[1] = 0;
      if (inc(x,xsm1) && dec(y))
	dst[2] = src[coor(x+1,y-1,z-1)];
      else
	dst[2] = 0;
      if (dec(x))
	dst[3] = src[coor(x-1,y,z-1)];
      else
	dst[3] = 0;
      dst[4] = src[coor(x,y,z-1)];
      if (inc(x,xsm1))
	dst[5] = src[coor(x+1,y,z-1)];
      else
	dst[5] = 0;
      if (dec(x) && inc(y,ysm1))
	dst[6] = src[coor(x-1,y+1,z-1)];
      else
	dst[6] = 0;
      if (inc(y,ysm1))
	dst[7] = src[coor(x,y+1,z-1)];
      else
	dst[7] = 0;
      if (inc(x,xsm1) && inc(y,ysm1))
	dst[8] = src[coor(x+1,y+1,z-1)];
      else
	dst[8] = 0;
    }
  else
    for (i=0; i<9; i++) dst[i] = 0;

  /* middle plane */
  if (dec(x) && dec(y))
    dst[9] = src[coor(x-1,y-1,z)];
  else
    dst[9] = 0;
  if (dec(y))
    dst[10] = src[coor(x,y-1,z)];
  else
    dst[10] = 0;
  if (inc(x,xsm1) && dec(y))
    dst[11] = src[coor(x+1,y-1,z)];
  else
    dst[11] = 0;
  if (dec(x))
    dst[12] = src[coor(x-1,y,z)];
  else
    dst[12] = 0;
  dst[13] = src[coor(x,y,z)];
  if (inc(x,xsm1))
    dst[14] = src[coor(x+1,y,z)];
  else
    dst[14] = 0;
  if (dec(x) && inc(y,ysm1))
    dst[15] = src[coor(x-1,y+1,z)];
  else
    dst[15] = 0;
  if (inc(y,ysm1))
    dst[16] = src[coor(x,y+1,z)];
  else
    dst[16] = 0;
  if (inc(x,xsm1) && inc(y,ysm1))
    dst[17] = src[coor(x+1,y+1,z)];
  else
    dst[17] = 0;
  
  /* upper plane */
  if (inc(z,zsm1))
    {   /* lowest 3x3 plane */
      if (dec(x) && dec(y))
	dst[18] = src[coor(x-1,y-1,z+1)];
      else
	dst[18] = 0;
      if (dec(y))
	dst[19] = src[coor(x,y-1,z+1)];
      else
	dst[19] = 0;
      if (inc(x,xsm1) && dec(y))
	dst[20] = src[coor(x+1,y-1,z+1)];
      else
	dst[20] = 0;
      if (dec(x))
	dst[21] = src[coor(x-1,y,z+1)];
      else
	dst[21] = 0;
      dst[22] = src[coor(x,y,z+1)];
      if (inc(x,xsm1))
	dst[23] = src[coor(x+1,y,z+1)];
      else
	dst[23] = 0;
      if (dec(x) && inc(y,ysm1))
	dst[24] = src[coor(x-1,y+1,z+1)];
      else
	dst[24] = 0;
      if (inc(y,ysm1))
	dst[25] = src[coor(x,y+1,z+1)];
      else
	dst[25] = 0;
      if (inc(x,xsm1) && inc(y,ysm1))
	dst[26] = src[coor(x+1,y+1,z+1)];
      else
	dst[26] = 0;
    }
  else
    for (i=18; i<27; i++) dst[i] = 0;

}


/* #define retext(res,num,val,index) { printf("found it in # %d, value = %d at %ld\n", \ */
/*                           num,(int) (val),(index)); \ */
/*                           res->value.c  = 1; \ */
/* 			  return(res); \ */
/*                         } */
#define retext(res,num,val,index) { \
                                    res->value.c  = 1; \
			            return(res); \
                                  }


/* test if a point in a byte array is an exterior point, i.e.
   if there is a zero point in the 6-neighbourhood return true
      otherwise false
 */
IDL_VPTR exterior(int argc, IDL_VPTR argv[])
{
  IDL_VPTR src, result;
  UCHAR * arr;
  int cvt=0;
  IDL_LONG index;
  IDL_LONG xs, ys, zs;
  IDL_LONG x, y, z, xy;
  static IDL_ALLTYPES retval;

  /* argument checking */
  src = argv[0];
  IDL_ENSURE_SIMPLE(src);
  IDL_ENSURE_ARRAY(src);

  index = IDL_LongScalar(argv[1]);

  if (src->value.arr->n_dim != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"input array has to be 3D");

  /* type checking */
  if (src->type != IDL_TYP_BYTE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Byte...");
      src = IDL_CvtByte(1, argv);
      cvt = TRUE;
    }

  result = IDL_Gettmp();
  result->type = IDL_TYP_BYTE;
  result->value.c = 0;  /* default: nothing found */

  arr = (UCHAR *) src->value.arr->data;

  xs = src->value.arr->dim[0];
  ys = src->value.arr->dim[1];
  zs = src->value.arr->dim[2];
  /* printf("xs: %ld, ys: %ld, zs: %ld\n",xs,ys,zs); */
  xy = index % (xs*ys);
  y = xy / xs;
  x = xy % xs;
  z = index / (xs*ys);
  /* printf("x: %ld, y: %ld, z: %ld\n",x,y,z); */

  if (dec(z) && !arr[coor(x,y,z-1)])
    retext(result,1,arr[coor(x,y,z-1)],coor(x,y,z-1));
  if (inc(z,zs-1) && !arr[coor(x,y,z+1)])
    retext(result,2,arr[coor(x,y,z+1)],coor(x,y,z+1));
  if (inc(x,xs-1) && !arr[coor(x+1,y,z)])
    retext(result,3,arr[coor(x+1,y,z)],coor(x+1,y,z));
  if (dec(x) && !arr[coor(x-1,y,z)])
    retext(result,4,arr[coor(x-1,y,z)],coor(x-1,y,z));
  if (inc(y,ys-1) && !arr[coor(x,y+1,z)])
    retext(result,5,arr[coor(x,y+1,z)],coor(x,y+1,z));
  if (dec(y) && !arr[coor(x,y-1,z)])
    retext(result,6,arr[coor(x,y-1,z)],coor(x,y-1,z));

  /* otherwise leave the value as zero */
  
  return(result);
}
