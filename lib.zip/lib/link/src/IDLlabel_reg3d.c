#include <stdio.h>
#include "export.h"
#include <strings.h>

#define vxs(var) (var)->value.arr->dim[0]
#define vys(var) (var)->value.arr->dim[1]
#define vzs(var) (var)->value.arr->dim[2]

void label_reg3d(UCHAR * src, IDL_LONG * inds, IDL_LONG * labs,
		 IDL_LONG dim[IDL_MAX_ARRAY_DIM]);
void label_reg(UCHAR * src, IDL_LONG * labs, IDL_LONG * inds,
	       IDL_LONG ind, IDL_LONG xs, IDL_LONG ys, IDL_LONG zs,
	       IDL_LONG label);

IDL_VPTR IDLlabel_reg3d(int argc, IDL_VPTR argv[])
{
  IDL_VPTR src, result, tmp;
  void *outdata, *tmpdata;
  int i, cvt=0;
  IDL_LONG arrsz;


  /* argument checking */
  src = argv[0];
  IDL_ENSURE_SIMPLE(src);
  IDL_ENSURE_ARRAY(src);


  if (src->value.arr->n_dim != 3)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"input array has to be 3D");

  /* type checking */
  if (src->type != IDL_TYP_BYTE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Byte...");
      src = IDL_CvtByte(1, argv);
      cvt = TRUE;
    }

  /* create variable to hold result */
  outdata = (void *) IDL_MakeTempArray(IDL_TYP_LONG, 3, src->value.arr->dim, 
                             IDL_BARR_INI_ZERO, &result);
  /* and a temporary variable */
  tmpdata = (void *) IDL_MakeTempArray(IDL_TYP_LONG, 3, src->value.arr->dim, 
                             IDL_BARR_INI_ZERO, &tmp);

  /* and actually label regions */
  label_reg3d(src->value.arr->data, tmpdata, outdata, src->value.arr->dim);

  /* cleanup */
  if (cvt) IDL_Deltmp(src);
  IDL_Deltmp(tmp);

  return(result);
}


  /* depends on the vars src, labs, n, new and label */
#define ichk(ind) { n = (ind);              \
		    if (src[n] && !labs[n]) \
                       {                    \
	                 inds[new++] = n;   \
	                 labs[n] = label;   \
                       }                    \
		  }

#define coor(x,y,z) ((x)+xs*((y)+(z)*ys))

void label_reg3d(UCHAR * src, IDL_LONG * inds, IDL_LONG * labs,
		 IDL_LONG dim[IDL_MAX_ARRAY_DIM])
{
  IDL_LONG xs, ys, zs;
  IDL_LONG x, y, z;
  IDL_LONG ind, label = 0;
  IDL_LONG arsz;
   
  xs = dim[0];
  ys = dim[1];
  zs = dim[2];
  arsz = xs*ys*zs;

  
  /* prelabel edges to avoid edge checking later */
  for (y=0; y<ys; y++)
    for (x=0; x<xs; x++)
       labs[coor(x,y,0)] = labs[coor(x,y,zs-1)] = arsz;
  for (z=0; z<zs; z++)
    for (x=0; x<xs; x++)
       labs[coor(x,0,z)] = labs[coor(x,ys-1,z)] = arsz;
  for (z=0; z<zs; z++)
    for (y=0; y<ys; y++)
       labs[coor(0,y,z)] = labs[coor(xs-1,y,z)] = arsz;

  ind = 0;
  for (z=0; z<zs; z++)
   for (y=0; y<ys; y++)
    for (x=0; x<xs; x++, ind++)
	{
	  /* start labeling new area if unlabeled foreground
	     voxel encountered */
	  /* printf("testing index %ld\n",ind); */
	  if (src[ind] && !labs[ind]) {
	    /* printf("starting labeling with label %ld"
		   " at index %ld\n",label+1,ind); */
	    labs[ind] = ++label; /* is now done in label_reg */
	    label_reg(src, labs, inds, ind, xs, ys, zs, label);
	  }
	}
  /* remove prelabel */
  for (y=0; y<ys; y++)
    for (x=0; x<xs; x++)
       labs[coor(x,y,0)] = labs[coor(x,y,zs-1)] = 0;
  for (z=0; z<zs; z++)
    for (x=0; x<xs; x++)
       labs[coor(x,0,z)] = labs[coor(x,ys-1,z)] = 0;
  for (z=0; z<zs; z++)
    for (y=0; y<ys; y++)
       labs[coor(0,y,z)] = labs[coor(xs-1,y,z)] = 0;
}


void label_reg(UCHAR * src, IDL_LONG * labs, IDL_LONG * inds,
	       IDL_LONG ind, IDL_LONG xs, IDL_LONG ys, IDL_LONG zs,
	       IDL_LONG label)
{
  IDL_LONG idx=0, i;
  IDL_LONG new = 0;
  IDL_LONG arrsz = xs*ys*zs;
  IDL_LONG x, y, z, xy;
  IDL_LONG n, nf;

  xy = ind % (xs*ys);
  x = xy % xs;
  y = xy / xs;
  z = ind / (xs*ys);
  /* printf("checking at (%ld,%ld,%ld)\n",x,y,z); */
  /* label the new pixel itself */
  labs[ind] = label;
  /* pseudo code for following bunch of commands */
/*   for each n=26-neighb of (x,y,z) */
/*     if (src[n] && !labs[n]) // it is a not yet labeled foreground point */
/*       { */
/* 	inds[++new] = n;     // queue it into the list of new pixels */
/* 	labs[n] = label;     // and label it with the current label  */
/*       } */
  /* process all 26 neighbours */
  /* lower plane */
  ichk(coor(x-1,y-1,z-1));
  ichk(coor(x,y-1,z-1));
  ichk(coor(x+1,y-1,z-1));
  ichk(coor(x-1,y,z-1));
  ichk(coor(x,y,z-1));
  ichk(coor(x+1,y,z-1));
  ichk(coor(x-1,y+1,z-1));
  ichk(coor(x,y+1,z-1));
  ichk(coor(x+1,y+1,z-1));
  /* middle plane */
  ichk(coor(x-1,y-1,z));
  ichk(coor(x,y-1,z));
  ichk(coor(x+1,y-1,z));
  ichk(coor(x-1,y,z));
  ichk(coor(x,y,z));
  ichk(coor(x+1,y,z));
  ichk(coor(x-1,y+1,z));
  ichk(coor(x,y+1,z));
  ichk(coor(x+1,y+1,z));
  /* upper plane */
  ichk(coor(x-1,y-1,z+1));
  ichk(coor(x,y-1,z+1));
  ichk(coor(x+1,y-1,z+1));
  ichk(coor(x-1,y,z+1));
  ichk(coor(x,y,z+1));
  ichk(coor(x+1,y,z+1));
  ichk(coor(x-1,y+1,z+1));
  ichk(coor(x,y+1,z+1));
  ichk(coor(x+1,y+1,z+1));

  while (new)
    {
      /* printf("found %ld new voxels\n",new); */
      nf = new;
      new = 0;
      /* copy newly found indices to the end */
      /* for (i=0; i<nf; i++)
	printf("%ld ",inds[i]);
	printf("\n");
      */
      bcopy(inds, inds+arrsz-nf, nf*sizeof(IDL_LONG));
      /* for (i=arrsz-1; i>arrsz-nf-1; i--)
	printf("%ld ",inds[i]);
      printf("\n");
      */
      for (i = arrsz-1; i>arrsz-nf-1; i--)
	{
	  idx = inds[i];
	  xy = idx % (xs*ys);
	  x = xy % xs;
	  y = xy / xs;
	  z = idx / (xs*ys);
	  /* printf("checking now at (%ld,%ld,%ld)\n",x,y,z); */
	  /* pseudo code for following bunch of commands */
	  /*   for each n=26-neighb of (x,y,z) */
	  /*     if (src[n] && !labs[n]) // it is a not yet 
		                            labeled foreground point */
	  /*       { */
	  /* 	inds[++new] = n;     // queue it into the list of new pixels */
	  /* 	labs[n] = label;     // and label it with the current label  */
	  /*       } */
	  /* process all 26 neighbours */
	  /* lower plane */
	  ichk(coor(x-1,y-1,z-1));
	  ichk(coor(x,y-1,z-1));
	  ichk(coor(x+1,y-1,z-1));
	  ichk(coor(x-1,y,z-1));
	  ichk(coor(x,y,z-1));
	  ichk(coor(x+1,y,z-1));
	  ichk(coor(x-1,y+1,z-1));
	  ichk(coor(x,y+1,z-1));
	  ichk(coor(x+1,y+1,z-1));
	  /* middle plane */
	  ichk(coor(x-1,y-1,z));
	  ichk(coor(x,y-1,z));
	  ichk(coor(x+1,y-1,z));
	  ichk(coor(x-1,y,z));
	  ichk(coor(x,y,z));
	  ichk(coor(x+1,y,z));
	  ichk(coor(x-1,y+1,z));
	  ichk(coor(x,y+1,z));
	  ichk(coor(x+1,y+1,z));
	  /* upper plane */
	  ichk(coor(x-1,y-1,z+1));
	  ichk(coor(x,y-1,z+1));
	  ichk(coor(x+1,y-1,z+1));
	  ichk(coor(x-1,y,z+1));
	  ichk(coor(x,y,z+1));
	  ichk(coor(x+1,y,z+1));
	  ichk(coor(x-1,y+1,z+1));
	  ichk(coor(x,y+1,z+1));
	  ichk(coor(x+1,y+1,z+1));
	}
    }
}
