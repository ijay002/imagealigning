#include <stdio.h>
#include "export.h"
#include <ifl/iflCdefs.h>

void write_rgb(int argc, IDL_VPTR argv[])
{
  IDL_VPTR src, im;
  const char *fname;
  char msg[1024];
  int wt,ht;
  int cvt = FALSE;
  unsigned char *data;

  iflFile *file;
  iflFileConfig *fc;
  iflStatus sts;
  iflSize dims;

  /* argument checking */
  src = argv[0];
  im = argv[1];
  IDL_ENSURE_STRING(src);


  IDL_ENSURE_SIMPLE(im);
  IDL_ENSURE_ARRAY(im);

  if (im->value.arr->n_dim != 2)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, 
		"input array has to be 2D");

  /* type checking */
  if (im->type != IDL_TYP_BYTE)
    {
      IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, "promoting to Byte...");
      im = IDL_CvtByte(1, &im);
      cvt = TRUE;
    }
  wt = im->value.arr->dim[0];
  ht = im->value.arr->dim[1];
  data = (unsigned char *) im->value.arr->data;

  fname = (const char*) IDL_STRING_STR(&(src->value.str));
  sprintf(msg,"Going to write RGB file \"%s\" (%ldx%ld pixels)",fname,
	  (long)wt,(long)ht);
  IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_INFO, 
		  msg);
  
  dims.x = wt;
  dims.y = ht;
  dims.z = 1;
  dims.c = 1;

  fc = iflFileConfigCreate(&dims, iflUChar, 0, 0, 0, 0, NULL);
  file = iflFileCreate(fname, NULL, fc, NULL, &sts);
  if (sts != iflOKAY)
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP,"coudn't create file");

  /* write a tile of data to it */
  sts = iflFileSetTile(file, 0, 0, 0, wt, ht, 1, data, NULL);
  if (sts != iflOKAY) {
    iflFileClose(file, 0);
    IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP,"coudn't write file");
  }
  iflFileClose(file, 0); /* important ! */

  /* cleanup */
  if (cvt) IDL_Deltmp(im);
}
