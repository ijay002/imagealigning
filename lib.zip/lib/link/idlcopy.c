#include <stdio.h>
#include "export.h"

IDL_VPTR idlcopy(int argc, IDL_VPTR argv[])
{
  IDL_VPTR src, result;

  /* argument checking */
  src = argv[0];
  IDL_ENSURE_SIMPLE(src);
  IDL_ENSURE_ARRAY(src);

  /* create variable to hold result */
  result = IDL_Gettmp();
  IDL_VarCopy(src,result);
  return(result);
}
