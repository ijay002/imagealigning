#include <stdio.h>
#include "export.h"

#define ARRLEN(arr) (sizeof(arr)/sizeof(arr[0]))

static IDL_VPTR helloworld(int argc, IDL_VPTR *argv)
{ return IDL_StrToSTRING("HelloWorld! from a dynamically loadable module."); }

int IDL_Load(void)
{
  static IDL_SYSFUN_DEF function_addr[] = {
    { helloworld, "HELLOWORLD", 0, IDL_MAX_ARRAY_DIM, 0}, 
  };

  return IDL_AddSystemRoutine(function_addr, TRUE, ARRLEN(function_addr));
}
