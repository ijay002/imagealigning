------------------------------------------------------------
README file: <RSI_Directory>
	       <IDL_Directory>
		  lib
		    obsolete
------------------------------------------------------------

This directory contains .pro files that define IDL routines
that have become obsolete. The routines included in this
directory will still function properly with IDL, but are
no longer recommended for inclusion in new code. See the
"Obsolete Routines" chapter of the IDL Reference Guide (or
Online Help) for information on Research Systems' policies
on obsolete routines.
